/**
 * Samsung Hospitality Launcher
 * Main application logic with TV remote control and input switching
 */

(function() {
    'use strict';

    // ============================================
    // CONFIGURATION
    // ============================================
    const CONFIG = {
        // Auto-hide logo if file doesn't exist
        logoFallback: true,
        
        // Timeout before switching (milliseconds)
        switchDelay: 500,
        
        // Default focused button on load
        defaultFocus: 'btn-wireless'
    };

    // ============================================
    // STATE MANAGEMENT
    // ============================================
    let currentFocusIndex = 0;
    let buttons = [];
    let isProcessing = false;

    // ============================================
    // SAMSUNG TIZEN TV APIs
    // ============================================
    const TizenTV = {
        // Check if running on Samsung TV
        isSupported: function() {
            return typeof tizen !== 'undefined' && 
                   typeof webapis !== 'undefined';
        },

        // Launch Wireless Screen Share (Knox)
        launchWirelessCast: function() {
            try {
                if (typeof webapis !== 'undefined' && webapis.avplay) {
                    // Method 1: Try to launch SmartView/Screen Mirroring
                    console.log('Attempting to launch Wireless Screen Share...');
                    
                    // Samsung's Screen Mirroring app ID
                    const screenMirrorAppId = 'com.samsung.tv-mirroring-launcher';
                    
                    tizen.application.launch(
                        screenMirrorAppId,
                        function() {
                            console.log('Wireless Screen Share launched successfully');
                        },
                        function(error) {
                            console.error('Failed to launch Screen Share:', error);
                            // Fallback: Show on-screen instructions
                            alert('To enable wireless casting:\n\n1. Press Source on remote\n2. Select "Screen Mirroring"\n3. Connect from your device');
                        }
                    );
                } else {
                    console.warn('AVPlay API not available');
                    this.showWirelessInstructions();
                }
            } catch (error) {
                console.error('Error launching wireless cast:', error);
                this.showWirelessInstructions();
            }
        },

        // Switch to HDMI input
        switchToHDMI: function(hdmiNumber) {
            try {
                console.log('Switching to HDMI', hdmiNumber);
                
                if (typeof webapis !== 'undefined' && webapis.tvinfo) {
                    // Get list of available inputs
                    const inputDevPlugin = webapis.tvinfo.getInputDeviceList();
                    
                    if (inputDevPlugin) {
                        // Find the HDMI input
                        const hdmiInput = inputDevPlugin.find(device => 
                            device.label && device.label.includes('HDMI ' + hdmiNumber)
                        );
                        
                        if (hdmiInput) {
                            // Switch to the input
                            webapis.tvinfo.setCurrentSource(hdmiInput);
                            console.log('Switched to HDMI ' + hdmiNumber);
                        } else {
                            console.error('HDMI ' + hdmiNumber + ' not found');
                            // Fallback to manual switching
                            this.showSourceSwitchInstructions(hdmiNumber);
                        }
                    }
                } else {
                    console.warn('TV Info API not available');
                    this.showSourceSwitchInstructions(hdmiNumber);
                }
            } catch (error) {
                console.error('Error switching HDMI:', error);
                this.showSourceSwitchInstructions(hdmiNumber);
            }
        },

        // Alternative method using TV Key simulation
        switchToHDMIByKey: function(hdmiNumber) {
            try {
                // Press Source button to bring up input menu
                tizen.tvinputdevice.registerKey('Source');
                
                // Then navigate to HDMI (this is device-specific)
                // This is a backup method
                console.log('Using key simulation for HDMI switch');
            } catch (error) {
                console.error('Key simulation failed:', error);
            }
        },

        // Show manual instructions
        showSourceSwitchInstructions: function(hdmiNumber) {
            alert('Please switch input manually:\n\n1. Press SOURCE on remote\n2. Select HDMI ' + hdmiNumber);
        },

        showWirelessInstructions: function() {
            alert('To enable wireless casting:\n\n1. Press SOURCE on remote\n2. Select "Screen Mirroring"\n3. Connect from your laptop\n\nOr use Samsung Knox app on your laptop');
        }
    };

    // ============================================
    // NAVIGATION & FOCUS MANAGEMENT
    // ============================================
    const Navigation = {
        init: function() {
            buttons = Array.from(document.querySelectorAll('.launcher-btn'));
            
            if (buttons.length === 0) return;

            // Set initial focus
            this.setFocus(0);

            // Register TV remote keys
            this.registerKeys();

            // Add mouse support for testing
            buttons.forEach((btn, index) => {
                btn.addEventListener('mouseenter', () => {
                    this.setFocus(index);
                });
            });
        },

        registerKeys: function() {
            if (TizenTV.isSupported()) {
                try {
                    // Arrow keys and Enter are built-in — do NOT register them
                    // Only register special keys that need explicit registration
                    tizen.tvinputdevice.registerKey('ColorF0Red');
                    tizen.tvinputdevice.registerKey('ColorF1Green');
                    tizen.tvinputdevice.registerKey('ColorF2Yellow');
                    tizen.tvinputdevice.registerKey('ColorF3Blue');
                } catch (error) {
                    console.error('Failed to register TV keys:', error);
                }
            }

            // Handle key presses
            document.addEventListener('keydown', (e) => {
                this.handleKeyPress(e);
            });
        },

        handleKeyPress: function(e) {
            if (isProcessing) return;

            switch(e.keyCode) {
                case 37: // LEFT arrow
                    e.preventDefault();
                    this.moveFocus(-1);
                    break;
                case 39: // RIGHT arrow
                    e.preventDefault();
                    this.moveFocus(1);
                    break;
                case 38: // UP arrow
                case 40: // DOWN arrow
                    e.preventDefault();
                    // Ignore up/down for horizontal grid
                    break;
                case 13: // OK / Enter button
                    e.preventDefault();
                    this.activateButton();
                    break;
                case 10009: // RETURN button — exit app
                    tizen.application.getCurrentApplication().exit();
                    break;
            }
        },

        setFocus: function(index) {
            // Remove focus from all buttons
            buttons.forEach(btn => btn.classList.remove('focused'));
            
            // Set new focus
            currentFocusIndex = index;
            buttons[currentFocusIndex].classList.add('focused');
            buttons[currentFocusIndex].focus();
        },

        moveFocus: function(direction) {
            let newIndex = currentFocusIndex + direction;
            
            // Wrap around
            if (newIndex < 0) {
                newIndex = buttons.length - 1;
            } else if (newIndex >= buttons.length) {
                newIndex = 0;
            }
            
            this.setFocus(newIndex);
        },

        activateButton: function() {
            if (currentFocusIndex >= 0 && currentFocusIndex < buttons.length) {
                buttons[currentFocusIndex].click();
            }
        }
    };

    // ============================================
    // BUTTON ACTION HANDLERS
    // ============================================
    const Actions = {
        init: function() {
            // Wireless Cast button
            document.getElementById('btn-wireless').addEventListener('click', () => {
                this.handleAction('wireless');
            });

            // HDMI 1 button
            document.getElementById('btn-hdmi1').addEventListener('click', () => {
                this.handleAction('hdmi1');
            });

            // Conference Mode (HDMI 2) button
            document.getElementById('btn-conference').addEventListener('click', () => {
                this.handleAction('hdmi2');
            });
        },

        handleAction: function(mode) {
            if (isProcessing) return;
            
            isProcessing = true;
            this.showLoading(true);

            console.log('Mode selected:', mode);

            // Delay before switching (smooth UX)
            setTimeout(() => {
                switch(mode) {
                case 'wireless':
                    try {
                        var appControl = new tizen.ApplicationControl(
                            "http://tizen.org/appcontrol/operation/view", 
                            null, 
                            null, 
                            null, 
                            [new tizen.ApplicationControlData("PAYLOAD", ["{\"target\":\"miracast\"}"])]
                        );

                        tizen.application.launchAppControl(
                            appControl, 
                            "org.tizen.screen-mirroring", 
                            function() { console.log("Discovery Mode Active"); },
                            function(e) { 
                                // Fallback for older Hospitality firmware
                                tizen.application.launch("com.samsung.tizen.screen-mirroring");
                            }
                        );
                    } catch (e) {
                        console.error("Manual Mirroring Launch Failed");
                    }
                    break;
                    case 'hdmi1':
                        TizenTV.switchToHDMI(1);
                        break;
                    case 'hdmi2':
                        TizenTV.switchToHDMI(2);
                        break;
                }

                // Hide loading after action
                setTimeout(() => {
                    this.showLoading(false);
                    isProcessing = false;
                }, 1500);
            }, CONFIG.switchDelay);
        },

        showLoading: function(show) {
            const overlay = document.getElementById('loadingOverlay');
            if (show) {
                overlay.classList.add('active');
            } else {
                overlay.classList.remove('active');
            }
        }
    };

    // ============================================
    // CLOCK FUNCTIONALITY
    // ============================================
    const Clock = {
        timeElement: null,
        dateElement: null,
        
        init: function() {
            this.timeElement = document.getElementById('clockTime');
            this.dateElement = document.getElementById('clockDate');
            
            if (!this.timeElement || !this.dateElement) {
                console.warn('Clock elements not found');
                return;
            }
            
            // Update immediately
            this.updateClock();
            
            // Update every second
            setInterval(() => {
                this.updateClock();
            }, 1000);
        },
        
        updateClock: function() {
            const now = new Date();
            
            // Format time (12-hour with AM/PM)
            let hours = now.getHours();
            const minutes = now.getMinutes();
            const ampm = hours >= 12 ? 'PM' : 'AM';
            hours = hours % 12;
            hours = hours ? hours : 12; // 0 should be 12
            const minutesStr = minutes < 10 ? '0' + minutes : minutes;
            
            this.timeElement.textContent = `${hours}:${minutesStr} ${ampm}`;
            
            // Format date
            const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
            const months = ['January', 'February', 'March', 'April', 'May', 'June', 
                          'July', 'August', 'September', 'October', 'November', 'December'];
            
            const dayName = days[now.getDay()];
            const monthName = months[now.getMonth()];
            const date = now.getDate();
            
            this.dateElement.textContent = `${dayName}, ${monthName} ${date}`;
        }
    };
    
    function displayTVName() {
        console.log("Attempting to fetch TV Name...");
        
        // Safety timeout: if API doesn't respond in 2 seconds, use fallback
        var timeout = setTimeout(function() {
            console.warn("SystemInfo timed out. Using fallback name.");
            document.getElementById('tv-name-display').innerText = "My Tizen TV";
        }, 2000);

        try {
            tizen.systeminfo.getPropertyValue("DEVICE_NAME", 
                function(device) {
                    clearTimeout(timeout);
                    console.log("Success! Name found:", device.deviceName);
                    // If the name is empty string (common in emulator), use fallback
                    document.getElementById('tv-name-display').innerText = device.deviceName || "Tizen Emulator";
                }, 
                function(error) {
                    clearTimeout(timeout);
                    console.error("API Error:", error.message);
                    document.getElementById('tv-name-display').innerText = "Tizen TV";
                }
            );
        } catch (e) {
            clearTimeout(timeout);
            console.error("SystemInfo Exception:", e);
            document.getElementById('tv-name-display').innerText = "Unknown TV";
        }
    }

    // Call the function when the window loads
    window.onload = displayTVName;
    // ============================================
    // UTILITIES
    // ============================================
    const Utils = {
        // Check if logo image exists, hide if not
        checkLogo: function() {
            const logo = document.getElementById('logo');
            if (!logo) return;

            const img = new Image();
            img.onload = function() {
                // Logo loaded successfully
                console.log('Logo loaded');
            };
            img.onerror = function() {
                // Logo not found, hide it
                if (CONFIG.logoFallback) {
                    logo.classList.add('hidden');
                    console.log('Logo not found, hiding element');
                }
            };
            img.src = logo.src;
        },

        // Log system info
        logSystemInfo: function() {
            console.log('=== Hospitality Launcher ===');
            console.log('Tizen API:', TizenTV.isSupported() ? 'Available' : 'Not available');
            
            if (TizenTV.isSupported()) {
                try {
                    console.log('TV Model:', webapis.productinfo.getModel());
                    console.log('Firmware:', webapis.productinfo.getFirmware());
                } catch (error) {
                    console.log('Could not retrieve TV info');
                }
            }
        }
    };

    // ============================================
    // APP INITIALIZATION
    // ============================================
    window.addEventListener('DOMContentLoaded', () => {
        console.log('Initializing Hospitality Launcher...');
        
        // Initialize all modules
        Utils.logSystemInfo();
        Utils.checkLogo();
        Clock.init();
        Navigation.init();
        Actions.init();
        
        console.log('Launcher ready!');
    });

    // Handle app visibility changes
    document.addEventListener('visibilitychange', () => {
        if (!document.hidden) {
            // App became visible again, reset focus
            Navigation.setFocus(0);
        }
    });

})();